// config structure and setup

const config = {
  'logging': false
}

try { 
  if (localStorage.getItem('EricomLogging') && localStorage.getItem('EricomLogging')  === 'true') {
    config.logging = true;
  }
} catch(err) {
 // console.info('Application logging enabled clientside: ', config.logging);
}
// console.info('Application logging enabled: ', config.logging);

if (!config.logging){
  console.log = function() {}
  console.warn = function() {}
  console.info = function() {}
  console.error = function() {}
  console.groupCollapsed = function() {}
  console.table = function() {}
  console.groupEnd = function() {}
}

// end config structure and setup