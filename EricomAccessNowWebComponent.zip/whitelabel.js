/*
White label configuration file.
To Change the background image and/or the logo image:
Please specify a path relative to the AccessNow start.html file that is available on the webserver

*/


var whiteLabel = {
  enabled: false, // enable or disable whitelabeling
  backgroundCss : 'url("resources/images/background-neuronal.jpg") no-repeat center center',  // path to body background css image
  logoSrc : 'resources/googlelogo.png', // path to logo image. Image will be scaled to 152x55 px
  
  // connection dialog whitelabel
  modalShowApplicationName : false, // show the application name connecting to  / logging in to
  modalConnectingText : 'Connecting to', // text while connecting
  modalDisplayLoggedIn: false, // show the status change from connecting to logged in 
  modalLoggedInText : 'Logged in to', // the text to be shown after the connection is successful 
  modalSpinner : '' // default connection spinner or replace with the custom image path - if empty falls back to default e.g.: 'resources/images/image.png'
};